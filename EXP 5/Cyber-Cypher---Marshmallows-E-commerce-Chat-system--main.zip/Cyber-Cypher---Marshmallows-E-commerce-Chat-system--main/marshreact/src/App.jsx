import React from 'react';
import Fetch from './FetchUI.jsx';
import './App.css';
const App = () => {
  return (
    <div>
      <h1></h1>
      
      <Fetch />
    </div>
  );
};

export default App;
