import React from 'react';
const sidebar = () => {
  return (
    <div>
      <h1></h1>
    </div>
  );
};

export default sidebar;
